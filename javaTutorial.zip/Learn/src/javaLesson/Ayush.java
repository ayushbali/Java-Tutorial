package javaLesson;

public class Ayush {

	public static void main(String[] args) {
// JAVA STRINGS

//		String name = "Ayush";

		// length()
//		System.out.println("The length of String is: " + name.length());

		// indexOf()
//		System.out.println("Index of A is: " + name.indexOf('A'));

		// substring()
//		System.out.println(name.substring(2));

		// split()
//		System.out.println(name.split("Ayush"));

		// replace()
//		System.out.println(name.replace('A', 'a'));

		// isEmpty()
//		System.out.println("Is Ayush empty? " + name.isEmpty());

		// isBlank()
//		System.out.println("Is Ayush blank? " + name.isBlank());

		// lastIndexOf()
//		System.out.println("Last index of 's' in Ayush is: " + name.lastIndexOf("s"));
		

// -------- METHODS--------
		
// calling the method
		method1();
		sayHello("Rishu");
		Add(6,3);
		System.out.println(Sub(10,5)); // passing the arguments directly to the method
		int sub = Sub(10,6); // creating a local var and assigning the method to it along with arguments
		System.out.println(sub);
		
//		CREATING STUDENT OBJECT
		
		StudentClass student = new StudentClass();   // student -> object
		student.name = "Ayush ";
		student.age = 21;
		student.id = "069420";
		System.out.println(student.name + student.age);
		
// Encapsulating StudentClass
		
		student.setName("Rishu ");
		student.setAge(21);
		System.out.println(student.getName() + student.getAge());
		
}

	
	public static void method1() {
		System.out.println("this is a method ");
	}
	
//	passing parameter & argument ==== in parameter passing we can't access the result SO to access use return
	public static void sayHello(String name) {
		System.out.println("hello "+ name);
	}
	public static void Add(int a, int b) {
		System.out.println(a+b);
	}
	public static int Sub(int a, int b) {
		int c = a-b;
		return (c);
	}
}
























