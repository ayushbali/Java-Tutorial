package javaLesson;

public class StudentClass {
//	This is a student class,  and it can have its own member methods & variables
//	Now we will create an object(instance of class) of Student class in our main class
	int age;
	String name;
	String id;
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
}
